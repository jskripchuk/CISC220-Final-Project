#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <limits>
#include <dirent.h>
#include <vector>
#include <string>
#include <map>
#include "ChordGraph.h"

using namespace std;

vector<char *> open (char* path){
  
  DIR* dir;
  dirent* pdir;
  vector<char *> files;
  
  dir = opendir(path);
  while (pdir = readdir(dir)){
    files.push_back(pdir->d_name);
  }
  
  return files;
}

int main(int argc, char **argv) {
  
  //cout << "Reading " << argv[1] << "..." << endl;
  vector<char *> files= open(argv[1]);
  ofstream output;
  ofstream flow;
  ofstream stats;
  output.open("graphs.txt");
  flow.open("flow.txt");
  stats.open("stats.txt");
  map<string, int> flowMap;
  map<string, int> degreeMap;
  string flowString;
  string degreeString;

  for (int i = 2; i < files.size(); i++){
    cout << files[i];
    ChordGraph cg;
    parseChords(cg, files[i], argv[1]);
    output << "*" << files[i] << endl;
    output << "*Graph:" << endl;
    output << cg.toString() << endl;
    flow << files[i] << endl;
    flowString = cg.doFordFulkerson();
    if (flowMap.find(flowString) == flowMap.end()){
      flowMap[flowString] = 1;
    } else {
      flowMap[flowString]++;
    }
    flow << "Max Flow: " << flowString;
    flow << endl;
    degreeString = cg.findMaxDegree();
    if (degreeMap.find(degreeString) == degreeMap.end()){
      degreeMap[degreeString] = 1;
    } else {
      degreeMap[degreeString]++;
    }
    flow << "Max Degree: "<< degreeString;
    flow << endl;
    flow << "-----------------------------------------" << endl;
  }
  
  stats << "Flow Stats" << endl;
  stats << "[Source Chord] -> [Target Chord] : [# of songs that this was the maximum flow]" << endl;
  stats << endl;
  for (auto iter = flowMap.begin(); iter != flowMap.end(); ++iter) {
        stats << iter->first << " : " << iter->second << endl;
  }
  
  stats << endl;
  stats << "-----------------------------------------" << endl;
  stats << endl;  
  
  stats << "Degree Stats" << endl;
  stats << "[Chord] : [# of songs that had a max degree of this chord]" << endl;
  stats << endl;
  for (auto iter = degreeMap.begin(); iter != degreeMap.end(); ++iter) {
        stats << iter->first << " : " << iter->second << endl;
  }
  
  output.close();
  flow.close();
  stats.close();
  

  return 0;
}
